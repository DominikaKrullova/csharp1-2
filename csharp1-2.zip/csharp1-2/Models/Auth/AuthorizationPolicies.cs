namespace Share.Auth;
using System.Security.Claims;
using Microsoft.Extensions.DependencyInjection;

public static class AuthorizationPolicies
{
    public static void AddPolicies(IServiceCollection services){}
}